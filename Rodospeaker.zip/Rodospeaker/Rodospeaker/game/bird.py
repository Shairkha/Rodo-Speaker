from ursina import *
import random as r

app = Ursina()

Sky()

# Bird Entity
bird = Animation(
    'assets/img',  # Replace with the correct path to your sprite image
    collider='box',
    scale=(2, 2, 2),
    y=5
)

# Camera settings
camera.orthographic = True
camera.fov = 20

# Pipe Entity
pipe = Entity(
    model='quad',
    color=color.green,
    texture='white_cube',
    position=(20, 10),
    scale=(3, 15, 1),
    collider='box'
)
pipes = []

# Function to create new pipes
def newPipe():
    y = r.randint(4, 12)
    new1 = duplicate(pipe, y=y)
    new2 = duplicate(pipe, y=y - 22)
    pipes.extend((new1, new2))
    invoke(newPipe, delay=5)

# Update function
def update():
    bird.y -= 4 * time.dt  # Gravity effect
    for p in pipes:
        p.x -= 2 * time.dt  # Move pipes left
    touch = bird.intersects()
    if touch.hit or bird.y < -10:  # Collision or out-of-bound check
        quit()

# Input function
def input(key):
    if key == 'space':  # Bird jump
        bird.y += 3

# Start generating pipes
newPipe()

# Run the application
app.run()
