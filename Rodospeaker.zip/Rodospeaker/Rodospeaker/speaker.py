import win32com.client as wincom

if __name__ == "__main__":
    # Initialize the Speech API voice
    speak = wincom.Dispatch("SAPI.SpVoice")
    print("Welcome to RoboSpeaker 1.1. Created by Shair Ali")
    
    while True:
        x = input("Enter what you want me to speak: ")
        
        if x.lower() == "q":
            print("Exiting RoboSpeaker. Goodbye!")
            break
        
        speak.Speak(x)  # Use the `Speak` method to convert text to speech
